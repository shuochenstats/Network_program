rm(list=ls())
path <- "D:/Dropbox/UMwork/2019/FCnetwork/simulation_20190315"
setwd(path)


###### part 1 change contrast-to-noise ratio ######

No_case <- 30
No_control <- 30
No_subject <- No_case + No_control
No_nodes <- 100
No_nodes_contrast <- 10

### CNR: 0.6, 0.8, 1.0, 1.2
# CNR <- 0.6
# CNR <- 0.8
# CNR <- 1
# CNR <- 1.2
CNR <- 1.5

# create folder to store files
(parameter_list <- paste0( "CNR(", CNR, ")_No_nodes(", No_nodes, ")_No_nodes_contrast(", No_nodes_contrast, ")_No_subject(", No_subject, ")"))
(names_folder <- file.path(path, parameter_list))
(names_folder_matrix <- file.path(path, parameter_list, "connectivity_matrices_sumulation"))

if (!file.exists(names_folder)) dir.create(names_folder)
if (!file.exists(names_folder_matrix)) dir.create(names_folder_matrix)

# output connectivity matrices
Filenames <- paste0(path, "/", parameter_list, "/connectivity_matrices_sumulation/subject_", c(paste0("0", 1:9), 10:No_subject), ".txt")

set.seed(20190315)
(shuffle_idx <- sample(1:No_nodes))

connectivity_matrices_array <- array(NA, c(No_nodes, No_nodes, No_subject))
for (i in c(1:No_case)) {
  cat(i, "\n")
  set.seed(i)
  contrast_matrix <- matrix(rnorm(No_nodes_contrast^2, mean = CNR, sd = 1), No_nodes_contrast)
  case_matrix <- matrix(rnorm(No_nodes^2, mean = 0, sd = 1), No_nodes)
  case_matrix[1:No_nodes_contrast, 1:No_nodes_contrast] <- contrast_matrix
  case_matrix <- case_matrix[shuffle_idx, shuffle_idx]
  connectivity_matrices_array[, , i] <- case_matrix
  write.table(case_matrix, file = Filenames[i], sep=" ", row.names = FALSE, col.names = FALSE)
}

for (i in c(1:No_control)+No_case) {
  cat(i, "\n")
  set.seed(i)
  control_matrix <- matrix(rnorm(No_nodes^2, mean = 0, sd = 1), No_nodes)
  control_matrix <- control_matrix[shuffle_idx, shuffle_idx]
  connectivity_matrices_array[, , i] <- control_matrix
  write.table(control_matrix, file = Filenames[i], sep=" ", row.names = FALSE, col.names = FALSE)
}

#output design matrix
designMatrix_simulation <- cbind(c(rep(1, No_case), rep(0, No_control)), c(rep(0, No_case), rep(1, No_control)))
write.table(designMatrix_simulation, file = paste0(path, "/", parameter_list, "/designMatrix_simulation.txt"), sep=" ", row.names = FALSE, col.names = FALSE)

#output COG
COG_mprc <- read.table(file = paste0(path, "/COG_mprc.txt"), sep=" ", header = FALSE)
COG_mprc_simulation <- COG_mprc[1:No_nodes, 1:3]
write.table(COG_mprc_simulation, file = paste0(path, "/", parameter_list, "/COG_mprc_simulation.txt"), sep=" ", row.names = FALSE, col.names = FALSE)

#output region label
region_label_mprc <- read.table(file = paste0(path, "/regionLabel_mprc.txt"), sep=" ", header = FALSE)
region_label_mprc_simulation <- region_label_mprc[1:No_nodes, 1]
write.table(region_label_mprc_simulation, file = paste0(path, "/", parameter_list, "/region_label_mprc_simulation.txt"), sep=" ", row.names = FALSE, col.names = FALSE)

# t test
nlogp <- matrix(NA, No_nodes, No_nodes)
tstatistic <- matrix(NA, No_nodes, No_nodes)

for (i in 1:(No_nodes-1)) {
  for (j in c((i+1):No_nodes)) {
    cat(i,",", j, "\n")
    ttest_temp <- t.test(connectivity_matrices_array[i, j, 1:No_case], connectivity_matrices_array[i, j, c(1:No_control)+No_case])
    nlogp[i, j] <- -log(ttest_temp$p.value)
    tstatistic[i, j] <- ttest_temp$statistic
  }
}


bitmap(file = paste0(path, "/", parameter_list, "/hist_ttest_statistic.jpeg"), res=300)
hist(c(tstatistic), main = "histogram of ttest statistic")
dev.off()



bitmap(file = paste0(path, "/", parameter_list, "/hist_nlogp.jpeg"), res=300)
hist(c(nlogp), main = "histogram of -log(p)")
dev.off()


pvals <- exp(-nlogp)
bitmap(file = paste0(path, "/", parameter_list, "/hist_pvalue.jpeg"), res=300)
hist(c(pvals), main = "histogram of p value")
dev.off()

a <- is.na(nlogp)
nlogp[a] <- 0
nlogp1 <- nlogp + t(nlogp)
library(openxlsx)
write.xlsx(nlogp1, file=paste0(path, "/", parameter_list, "/nlogp.xlsx"), colNames=FALSE)

library(reshape2)
melted_nlogp1 <- melt(nlogp1)
head(melted_nlogp1)
melted_nlogp1$Var2 <- factor(melted_nlogp1$Var2, levels = rev(unique(melted_nlogp1$Var2)))
melted_nlogp1$Var1 <- factor(melted_nlogp1$Var1, levels = unique(melted_nlogp1$Var1))

library(ClassDiscovery)
library(ggplot2)
heatmap_nlogp <- ggplot(data = melted_nlogp1, aes(x=Var1, y=Var2, fill=value)) + 
  geom_tile()+
  scale_fill_gradientn(colours = jetColors(30), name="-log(p)")
heatmap_nlogp
ggsave(filename=paste0(path, "/", parameter_list, "/heatmap_nlogp.jpeg"), heatmap_nlogp, dpi=300, units = "in", width = 8, height = 6.5)


BHfdr <- p.adjust(pvals, method = "BH")
BHfdr <- matrix(BHfdr, No_nodes)
bitmap(file = paste0(path, "/", parameter_list, "/hist_BHfdr.jpeg"), res=300)
hist(c(BHfdr), main = "histogram of BH fdr")
dev.off()

# a <- na.omit(pvals[1, ])
# b <- p.adjust(a, method = "BH")
# names(b)
# 
# to.upper<-function(X) t(X)[lower.tri(X,diag=FALSE)]
# a <- to.upper(pvals)
# b <- p.adjust(a, method = "BH")
